package com.arimac.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyProductArimacApplicationTests {

	@Test
	void contextLoads() {
	}

}
